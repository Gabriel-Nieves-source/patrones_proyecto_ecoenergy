-- =========================================================
-- RUTA: database/ecoenergy.sql
-- Proyecto: EcoEnergy - Sprint 1
-- Descripción: Script completo de creación de base de datos
-- =========================================================

DROP DATABASE IF EXISTS ecoenergy;
CREATE DATABASE ecoenergy
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ecoenergy;

-- ---------------------------------------------------------
-- TABLA: usuarios
-- Relación: 1 usuario -> N hogares
-- ---------------------------------------------------------
CREATE TABLE usuarios (
    id_usuario      INT AUTO_INCREMENT PRIMARY KEY,
    nombre_completo VARCHAR(150) NOT NULL,
    correo          VARCHAR(150) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    fecha_creacion  DATETIME DEFAULT CURRENT_TIMESTAMP,
    activo          TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: categorias
-- Catálogo básico de categorías de electrodomésticos
-- Relación: 1 categoria -> N electrodomesticos
-- ---------------------------------------------------------
CREATE TABLE categorias (
    id_categoria    INT AUTO_INCREMENT PRIMARY KEY,
    nombre          VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: hogares
-- Relación: N hogares -> 1 usuario
-- Relación: 1 hogar -> N electrodomesticos
-- ---------------------------------------------------------
CREATE TABLE hogares (
    id_hogar        INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario      INT NOT NULL,
    nombre_hogar    VARCHAR(100) NOT NULL,
    fecha_creacion  DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_hogar_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: electrodomesticos
-- Relación: N electrodomesticos -> 1 hogar
-- Relación: N electrodomesticos -> 1 categoria
-- ---------------------------------------------------------
CREATE TABLE electrodomesticos (
    id_electrodomestico INT AUTO_INCREMENT PRIMARY KEY,
    id_hogar             INT NOT NULL,
    id_categoria         INT NOT NULL,
    nombre                VARCHAR(100) NOT NULL,
    potencia_watts        DECIMAL(10,2) NOT NULL,
    cantidad              INT NOT NULL DEFAULT 1,
    horas_uso_diario      DECIMAL(5,2) NOT NULL,
    dias_uso_semana       TINYINT NOT NULL,
    fecha_creacion        DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_electro_hogar
        FOREIGN KEY (id_hogar) REFERENCES hogares(id_hogar)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT fk_electro_categoria
        FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,

    CONSTRAINT chk_potencia_positiva CHECK (potencia_watts > 0),
    CONSTRAINT chk_cantidad_positiva CHECK (cantidad > 0),
    CONSTRAINT chk_horas_validas CHECK (horas_uso_diario > 0 AND horas_uso_diario <= 24),
    CONSTRAINT chk_dias_validos CHECK (dias_uso_semana BETWEEN 1 AND 7)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TABLA: tarifas
-- Tabla de configuración. Se deja preparada para que un
-- administrador la actualice en una futura iteración.
-- Solo debe existir una fila "activa" a la vez.
-- ---------------------------------------------------------
CREATE TABLE tarifas (
    id_tarifa       INT AUTO_INCREMENT PRIMARY KEY,
    valor_kwh_cop   DECIMAL(10,2) NOT NULL,
    activa          TINYINT(1) NOT NULL DEFAULT 1,
    fecha_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_tarifa_no_negativa CHECK (valor_kwh_cop >= 0)
) ENGINE=InnoDB;

-- =========================================================
-- DATOS INICIALES
-- =========================================================

-- Categorías básicas (según prompt del proyecto)
INSERT INTO categorias (nombre) VALUES
('Refrigeración'),
('Iluminación'),
('Entretenimiento'),
('Cocina'),
('Lavado'),
('Climatización'),
('Otros');

-- Tarifa de referencia inicial (COP por kWh, valor de ejemplo)
INSERT INTO tarifas (valor_kwh_cop, activa) VALUES (850.00, 1);

-- =========================================================
-- NOTA SOBRE INTEGRACIÓN FUTURA DE IA
-- No se crea tabla para IA en Sprint 1. Cuando se implemente,
-- se sugiere una tabla `recomendaciones_ia` con FK a
-- id_hogar y id_usuario, para almacenar el historial de
-- interacciones sin modificar las tablas existentes.
-- =========================================================
