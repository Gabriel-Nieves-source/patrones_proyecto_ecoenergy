# EcoEnergy — Pruebas manuales Sprint 1

Casos de prueba para usar como evidencia de entrega. Cada uno indica
entrada exacta, pasos y resultado esperado verificable en pantalla y/o MySQL.

---

## HU-01 — Gestión de hogares (crear hogar)

**Entrada:**
- Usuario autenticado (ver HU-06 primero).
- En `hogares.html`, campo "Nombre del hogar": `Casa Principal`

**Pasos:**
1. Iniciar sesión.
2. Ir a "Mis Hogares".
3. Escribir `Casa Principal` y presionar "Crear hogar".

**Resultado esperado:**
- Mensaje verde: "Hogar creado correctamente."
- El hogar aparece inmediatamente en la tabla con su fecha de creación.
- En MySQL: `SELECT * FROM hogares WHERE nombre_hogar = 'Casa Principal';`
  devuelve 1 fila con el `id_usuario` correcto.

**Prueba complementaria — aislamiento entre cuentas:**
- Crear un segundo usuario (correo distinto) e iniciar sesión con él.
- Ir a "Mis Hogares": la tabla debe estar vacía o mostrar solo los hogares
  de esa segunda cuenta, **nunca** "Casa Principal".

---

## HU-02 — Registro de electrodomésticos

**Entrada** (sobre el hogar "Casa Principal"):

| Campo | Valor |
|---|---|
| Nombre | Nevera |
| Categoría | Refrigeración |
| Potencia (Watts) | 300 |
| Cantidad | 1 |
| Horas de uso diario | 24 |
| Días de uso por semana | 7 |

**Pasos:**
1. Ir a "Electrodomésticos" con "Casa Principal" como hogar activo.
2. Llenar el formulario con los valores de la tabla.
3. Presionar "Guardar electrodoméstico".

**Resultado esperado:**
- Mensaje: "Electrodoméstico registrado correctamente."
- La nevera aparece en la tabla inferior con los datos ingresados.
- En MySQL: `SELECT * FROM electrodomesticos WHERE nombre = 'Nevera';`
  devuelve 1 fila asociada al `id_hogar` de "Casa Principal".

**Prueba de validación (debe fallar):**
- Intentar registrar un electrodoméstico con Potencia = `0` o Días de uso = `8`.
- Resultado esperado: mensaje de error en frontend ("valores numéricos deben
  ser positivos y estar en rangos válidos") y el backend también rechaza la
  petición si se intenta sortear el frontend (código 400).

---

## HU-03 — Cálculo de consumo

**Entrada:** la "Nevera" registrada en HU-02 (300 W, 1 unidad, 24 h/día,
7 días/semana).

**Pasos:**
1. Ir a "Dashboard" o "Estadísticas" con "Casa Principal" activo.
2. Observar el consumo mensual mostrado para "Nevera".

**Resultado esperado (verificación matemática):**
```
consumo_diario  = (300 × 1 × 24) / 1000        = 7.2 kWh
consumo_semanal = 7.2 × 7                       = 50.4 kWh
consumo_mensual = 50.4 × 4.345                  ≈ 218.99 kWh
consumo_anual   = 218.99 × 12                   ≈ 2627.9 kWh
```
- El valor mostrado en pantalla para consumo mensual debe ser aproximadamente
  **219 kWh** (cercano al ejemplo de referencia de 216 kWh/mes del enunciado,
  con la diferencia explicada por usar 4.345 semanas/mes en vez de
  exactamente 30 días).

**Prueba de recalculo automático (criterio "si se modifica, se actualiza"):**
1. Editar la Nevera y cambiar Horas de uso diario de `24` a `12`.
2. Guardar.
3. Volver al Dashboard.
4. Resultado esperado: el consumo mensual mostrado se reduce aproximadamente
   a la mitad (~109.5 kWh), sin recargar manualmente ni limpiar caché.

---

## HU-04 — Cálculo de costo

**Entrada:** tarifa inicial cargada por el script SQL: `850.00 COP/kWh`.
Nevera con consumo mensual ≈ 219 kWh.

**Pasos:**
1. Ir a "Dashboard" con "Casa Principal" activo.
2. Observar la tarjeta "Costo mensual estimado".

**Resultado esperado (verificación matemática):**
```
costo_mensual = 218.99 kWh × 850 COP ≈ $186,142 COP
```
- El valor mostrado debe coincidir (con margen de redondeo) y aparecer
  formateado como moneda colombiana, ej. `$186.142`.
- Debe distinguirse visualmente de la cifra en kWh (tarjetas de colores
  distintos: verde para consumo, azul para costo).

**Prueba de tarifa no negativa:**
- Verificar en MySQL: `SELECT * FROM tarifas;` — el
  `CHECK (valor_kwh_cop >= 0)` impide insertar una tarifa negativa
  directamente por SQL
  (`INSERT INTO tarifas (valor_kwh_cop) VALUES (-100);` debe fallar).

---

## HU-05 — Dashboard

**Entrada:** hogar "Casa Principal" con al menos 2 electrodomésticos
registrados (agregar una segunda entrada: "Televisor", Entretenimiento,
150 W, 1 unidad, 5 horas/día, 7 días/semana).

**Pasos:**
1. Ir a "Dashboard".
2. Observar las 4 tarjetas de métricas, el texto de "mayor consumidor",
   el gráfico de barras y la tabla de detalle.

**Resultado esperado:**
- Las 4 tarjetas muestran consumo/costo mensual y anual del **hogar
  completo** (suma de Nevera + Televisor).
- El texto de "mayor consumidor" identifica correctamente a "Nevera"
  (mayor kWh mensual que el Televisor).
- El gráfico de barras muestra dos barras, una por cada electrodoméstico,
  con alturas proporcionales a su consumo mensual.
- La tabla de detalle lista ambos equipos con sus valores individuales.

**Prueba de aislamiento por hogar:**
1. Crear un segundo hogar, ej. "Apartamento", sin electrodomésticos.
2. Cambiar el selector de "Hogar activo" a "Apartamento".
3. Resultado esperado: todas las métricas se resetean a 0 / "sin datos",
   y **no** se mezclan con los datos de "Casa Principal".

---

## HU-06 — Login (y registro)

### Caso A — Registro exitoso

**Entrada:**

| Campo | Valor |
|---|---|
| Nombre completo | María Gómez |
| Correo | maria@ejemplo.com |
| Contraseña | eco2026! |
| Confirmar contraseña | eco2026! |

**Resultado esperado:**
- Mensaje: "Cuenta creada correctamente." y redirección automática al login.
- En MySQL: `SELECT correo, password_hash FROM usuarios WHERE
  correo='maria@ejemplo.com';` muestra el correo, y `password_hash` es una
  cadena bcrypt (empieza con `$2b$...`), **nunca** el texto `eco2026!` en claro.

### Caso B — Login exitoso

**Entrada:** correo `maria@ejemplo.com`, contraseña `eco2026!`.

**Resultado esperado:**
- Redirección a `dashboard.html`.
- En el navegador (DevTools → Application → Local Storage): existe
  `eco_token` (JWT) y `eco_usuario` con los datos del usuario.

### Caso C — Login fallido (credenciales incorrectas)

**Entrada:** correo `maria@ejemplo.com`, contraseña `incorrecta123`.

**Resultado esperado:**
- Mensaje de error: "Credenciales incorrectas."
- No se guarda ningún token ni se redirige.

### Caso D — Protección de rutas sin sesión

**Pasos:** Sin haber iniciado sesión (o tras cerrar sesión), intentar
acceder directamente a `dashboard.html` escribiendo la URL.

**Resultado esperado:**
- `protegerPagina()` detecta la ausencia de `eco_token` y redirige
  inmediatamente a `index.html`.

### Caso E — Cierre de sesión

**Pasos:** Con sesión activa, presionar el botón "Salir" en la barra superior.

**Resultado esperado:**
- Se limpia `localStorage` (token, usuario, hogar seleccionado).
- Redirección a `index.html`.
- Intentar volver atrás con el botón del navegador y acceder al dashboard
  debe redirigir de nuevo al login (por `protegerPagina()`).

---

## Tabla resumen de evidencia para el Sprint 1

| HU | Prueba | Estado esperado |
|---|---|---|
| HU-01 | Crear, editar, eliminar y aislar hogares | ✅ Cumple |
| HU-02 | CRUD de electrodomésticos con validaciones | ✅ Cumple |
| HU-03 | Cálculo automático diario/mensual/anual y recalculo | ✅ Cumple |
| HU-04 | Costo en COP, diferenciado de kWh, tarifa no negativa | ✅ Cumple |
| HU-05 | Dashboard con mayor consumidor, gráfico y aislamiento por hogar | ✅ Cumple |
| HU-06 | Registro, login, hash de contraseña, protección de rutas, logout | ✅ Cumple |
