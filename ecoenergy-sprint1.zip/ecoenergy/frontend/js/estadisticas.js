// Logica de la pagina de estadisticas: grafico circular, de barras
// y tabla con porcentaje de participacion de cada electrodomestico.

let graficoTorta = null;
let graficoBarras = null;

document.addEventListener('DOMContentLoaded', async () => {
  protegerPagina();
  renderizarBarraSuperior('estadisticas');

  await cargarHogaresEnSelector();

  const hogarActivo = obtenerHogarSeleccionado();
  if (!hogarActivo) {
    mostrarSinHogar();
    return;
  }

  mostrarContenido();
  await cargarEstadisticas();

  document.getElementById('selector_hogar').addEventListener('change', (evento) => {
    guardarHogarSeleccionado(evento.target.value);
    cargarEstadisticas();
  });
});

function mostrarSinHogar() {
  document.getElementById('sin-hogar-aviso').style.display = 'block';
  document.getElementById('contenido-estadisticas').style.display = 'none';
}

function mostrarContenido() {
  document.getElementById('sin-hogar-aviso').style.display = 'none';
  document.getElementById('contenido-estadisticas').style.display = 'block';
}

async function cargarHogaresEnSelector() {
  try {
    const hogares = await apiFetch('/hogares');
    const selector = document.getElementById('selector_hogar');
    selector.innerHTML = '';

    if (hogares.length === 0) {
      mostrarSinHogar();
      return;
    }

    const hogarActivo = obtenerHogarSeleccionado();

    hogares.forEach((hogar) => {
      const opcion = document.createElement('option');
      opcion.value = hogar.id_hogar;
      opcion.textContent = hogar.nombre_hogar;
      if (String(hogar.id_hogar) === String(hogarActivo)) {
        opcion.selected = true;
      }
      selector.appendChild(opcion);
    });

    if (!hogarActivo) {
      guardarHogarSeleccionado(hogares[0].id_hogar);
    }
  } catch (error) {
    console.error(error);
  }
}

async function cargarEstadisticas() {
  const id_hogar = obtenerHogarSeleccionado();
  if (!id_hogar) return;

  try {
    const datos = await apiFetch(`/consumo/hogar/${id_hogar}`);
    const detalle = datos.detalle_por_electrodomestico || [];
    const totalMensual = datos.resumen_hogar.consumo_mensual_kwh || 0;

    pintarGraficoTorta(detalle);
    pintarGraficoBarras(detalle);
    pintarTablaEstadisticas(detalle, totalMensual);
  } catch (error) {
    console.error(error);
  }
}

const COLORES = ['#2e7d32', '#0288d1', '#66bb6a', '#4fc3f7', '#1b5e20', '#01579b', '#81c784', '#29b6f6'];

function pintarGraficoTorta(detalle) {
  const contexto = document.getElementById('grafico-torta').getContext('2d');
  if (graficoTorta) graficoTorta.destroy();
  if (detalle.length === 0) return;

  graficoTorta = new Chart(contexto, {
    type: 'pie',
    data: {
      labels: detalle.map((e) => e.nombre),
      datasets: [
        {
          data: detalle.map((e) => e.consumo_mensual_kwh),
          backgroundColor: detalle.map((_, i) => COLORES[i % COLORES.length])
        }
      ]
    },
    options: { responsive: true, maintainAspectRatio: false }
  });
}

function pintarGraficoBarras(detalle) {
  const contexto = document.getElementById('grafico-barras').getContext('2d');
  if (graficoBarras) graficoBarras.destroy();
  if (detalle.length === 0) return;

  graficoBarras = new Chart(contexto, {
    type: 'bar',
    data: {
      labels: detalle.map((e) => e.nombre),
      datasets: [
        {
          label: 'Consumo mensual (kWh)',
          data: detalle.map((e) => e.consumo_mensual_kwh),
          backgroundColor: '#0288d1'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
}

function pintarTablaEstadisticas(detalle, totalMensual) {
  const cuerpoTabla = document.getElementById('tabla-estadisticas');
  cuerpoTabla.innerHTML = '';

  if (detalle.length === 0) {
    cuerpoTabla.innerHTML = `<tr><td colspan="5">No hay datos disponibles.</td></tr>`;
    return;
  }

  detalle.forEach((equipo) => {
    const porcentaje = totalMensual > 0 ? ((equipo.consumo_mensual_kwh / totalMensual) * 100).toFixed(1) : '0.0';
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td>${equipo.nombre}</td>
      <td>${formatoKwh(equipo.consumo_diario_kwh)}</td>
      <td>${formatoKwh(equipo.consumo_mensual_kwh)}</td>
      <td>${formatoKwh(equipo.consumo_anual_kwh)}</td>
      <td>${porcentaje}%</td>
    `;
    cuerpoTabla.appendChild(fila);
  });
}
