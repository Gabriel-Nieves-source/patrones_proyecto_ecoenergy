// Logica de la pagina de registro de usuario.

document.addEventListener('DOMContentLoaded', () => {
  if (obtenerToken()) {
    window.location.href = 'dashboard.html';
    return;
  }

  const formulario = document.getElementById('form-registro');

  formulario.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    ocultarMensaje('mensaje-registro');
    ocultarMensaje('mensaje-exito-registro');

    const nombre_completo = document.getElementById('nombre_completo').value.trim();
    const correo = document.getElementById('correo').value.trim();
    const password = document.getElementById('password').value;
    const confirmar_password = document.getElementById('confirmar_password').value;

    if (!nombre_completo || !correo || !password || !confirmar_password) {
      mostrarMensaje('mensaje-registro', 'Todos los campos son obligatorios.');
      return;
    }

    if (password.length < 6) {
      mostrarMensaje('mensaje-registro', 'La contrasena debe tener minimo 6 caracteres.');
      return;
    }

    if (password !== confirmar_password) {
      mostrarMensaje('mensaje-registro', 'Las contrasenas no coinciden.');
      return;
    }

    try {
      await apiFetch('/auth/registro', {
        method: 'POST',
        body: JSON.stringify({ nombre_completo, correo, password, confirmar_password })
      });

      mostrarMensaje(
        'mensaje-exito-registro',
        'Cuenta creada correctamente. Redirigiendo al inicio de sesion...',
        'exito'
      );

      setTimeout(() => {
        window.location.href = 'index.html';
      }, 1800);
    } catch (error) {
      mostrarMensaje('mensaje-registro', error.message);
    }
  });
});
