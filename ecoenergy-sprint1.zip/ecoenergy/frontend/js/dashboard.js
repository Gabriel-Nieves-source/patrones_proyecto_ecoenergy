// Logica del Dashboard: consumo total, costo, mayor consumidor y grafico.

let graficoDashboard = null;

document.addEventListener('DOMContentLoaded', async () => {
  protegerPagina();
  renderizarBarraSuperior('dashboard');

  await cargarHogaresEnSelector();

  const hogarActivo = obtenerHogarSeleccionado();
  if (!hogarActivo) {
    mostrarSinHogar();
    return;
  }

  mostrarContenido();
  await cargarDashboard();

  document.getElementById('selector_hogar').addEventListener('change', (evento) => {
    guardarHogarSeleccionado(evento.target.value);
    cargarDashboard();
  });
});

function mostrarSinHogar() {
  document.getElementById('sin-hogar-aviso').style.display = 'block';
  document.getElementById('contenido-dashboard').style.display = 'none';
}

function mostrarContenido() {
  document.getElementById('sin-hogar-aviso').style.display = 'none';
  document.getElementById('contenido-dashboard').style.display = 'block';
}

async function cargarHogaresEnSelector() {
  try {
    const hogares = await apiFetch('/hogares');
    const selector = document.getElementById('selector_hogar');
    selector.innerHTML = '';

    if (hogares.length === 0) {
      mostrarSinHogar();
      return;
    }

    const hogarActivo = obtenerHogarSeleccionado();

    hogares.forEach((hogar) => {
      const opcion = document.createElement('option');
      opcion.value = hogar.id_hogar;
      opcion.textContent = hogar.nombre_hogar;
      if (String(hogar.id_hogar) === String(hogarActivo)) {
        opcion.selected = true;
      }
      selector.appendChild(opcion);
    });

    if (!hogarActivo) {
      guardarHogarSeleccionado(hogares[0].id_hogar);
    }
  } catch (error) {
    console.error(error);
  }
}

async function cargarDashboard() {
  const id_hogar = obtenerHogarSeleccionado();
  if (!id_hogar) return;

  try {
    const datos = await apiFetch(`/consumo/hogar/${id_hogar}`);
    pintarMetricas(datos);
    pintarMayorConsumidor(datos.mayor_consumidor);
    pintarTablaDetalle(datos.detalle_por_electrodomestico);
    pintarGrafico(datos.detalle_por_electrodomestico);
  } catch (error) {
    console.error(error);
  }
}

function pintarMetricas(datos) {
  const resumen = datos.resumen_hogar;
  document.getElementById('valor-consumo-mensual').textContent = formatoKwh(resumen.consumo_mensual_kwh);
  document.getElementById('valor-costo-mensual').textContent = formatoCOP(resumen.costo_mensual_cop);
  document.getElementById('valor-consumo-anual').textContent = formatoKwh(resumen.consumo_anual_kwh);
  document.getElementById('valor-costo-anual').textContent = formatoCOP(resumen.costo_anual_cop);
}

function pintarMayorConsumidor(mayor) {
  const texto = document.getElementById('mayor-consumidor-texto');
  if (!mayor) {
    texto.textContent = 'Aun no hay electrodomesticos registrados en este hogar.';
    return;
  }
  texto.innerHTML = `<strong>${mayor.nombre}</strong> (${mayor.categoria}) consume aproximadamente
    ${formatoKwh(mayor.consumo_mensual_kwh)} al mes, con un costo estimado de ${formatoCOP(mayor.costo_mensual_cop)}.`;
}

function pintarTablaDetalle(detalle) {
  const cuerpoTabla = document.getElementById('tabla-dashboard');
  cuerpoTabla.innerHTML = '';

  if (!detalle || detalle.length === 0) {
    cuerpoTabla.innerHTML = `<tr><td colspan="4">No hay electrodomesticos registrados.</td></tr>`;
    return;
  }

  detalle.forEach((equipo) => {
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td>${equipo.nombre}</td>
      <td>${equipo.categoria}</td>
      <td>${formatoKwh(equipo.consumo_mensual_kwh)}</td>
      <td>${formatoCOP(equipo.costo_mensual_cop)}</td>
    `;
    cuerpoTabla.appendChild(fila);
  });
}

function pintarGrafico(detalle) {
  const contexto = document.getElementById('grafico-dashboard').getContext('2d');

  if (graficoDashboard) {
    graficoDashboard.destroy();
  }

  if (!detalle || detalle.length === 0) {
    return;
  }

  graficoDashboard = new Chart(contexto, {
    type: 'bar',
    data: {
      labels: detalle.map((e) => e.nombre),
      datasets: [
        {
          label: 'Consumo mensual (kWh)',
          data: detalle.map((e) => e.consumo_mensual_kwh),
          backgroundColor: '#2e7d32'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
}
