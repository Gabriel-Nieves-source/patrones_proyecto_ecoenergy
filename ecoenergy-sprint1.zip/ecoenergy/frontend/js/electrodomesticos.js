// Logica de gestion de electrodomesticos (CRUD) para el hogar activo.

let categoriasCache = [];

document.addEventListener('DOMContentLoaded', async () => {
  protegerPagina();
  renderizarBarraSuperior('electrodomesticos');

  await cargarHogaresEnSelector();

  const hogarActivo = obtenerHogarSeleccionado();
  if (!hogarActivo) {
    mostrarSinHogar();
    return;
  }

  mostrarContenido();
  await cargarCategorias();
  await cargarElectrodomesticos();

  document.getElementById('selector_hogar').addEventListener('change', (evento) => {
    guardarHogarSeleccionado(evento.target.value);
    cargarElectrodomesticos();
  });

  document.getElementById('form-electrodomestico').addEventListener('submit', guardarElectrodomestico);
  document.getElementById('btn-cancelar-edicion').addEventListener('click', cancelarEdicion);
});

function mostrarSinHogar() {
  document.getElementById('sin-hogar-aviso').style.display = 'block';
  document.getElementById('contenido-electrodomesticos').style.display = 'none';
}

function mostrarContenido() {
  document.getElementById('sin-hogar-aviso').style.display = 'none';
  document.getElementById('contenido-electrodomesticos').style.display = 'block';
}

async function cargarHogaresEnSelector() {
  try {
    const hogares = await apiFetch('/hogares');
    const selector = document.getElementById('selector_hogar');
    selector.innerHTML = '';

    if (hogares.length === 0) {
      mostrarSinHogar();
      return;
    }

    const hogarActivo = obtenerHogarSeleccionado();

    hogares.forEach((hogar) => {
      const opcion = document.createElement('option');
      opcion.value = hogar.id_hogar;
      opcion.textContent = hogar.nombre_hogar;
      if (String(hogar.id_hogar) === String(hogarActivo)) {
        opcion.selected = true;
      }
      selector.appendChild(opcion);
    });

    // Si no habia hogar guardado, se toma el primero de la lista.
    if (!hogarActivo) {
      guardarHogarSeleccionado(hogares[0].id_hogar);
    }
  } catch (error) {
    mostrarMensaje('mensaje-electro', error.message);
  }
}

async function cargarCategorias() {
  try {
    categoriasCache = await apiFetch('/electrodomesticos/categorias');
    const selector = document.getElementById('id_categoria');
    selector.innerHTML = categoriasCache
      .map((cat) => `<option value="${cat.id_categoria}">${cat.nombre}</option>`)
      .join('');
  } catch (error) {
    mostrarMensaje('mensaje-electro', error.message);
  }
}

async function cargarElectrodomesticos() {
  const id_hogar = obtenerHogarSeleccionado();
  if (!id_hogar) return;

  try {
    const equipos = await apiFetch(`/electrodomesticos/hogar/${id_hogar}`);
    pintarTablaElectrodomesticos(equipos);
  } catch (error) {
    mostrarMensaje('mensaje-electro', error.message);
  }
}

function pintarTablaElectrodomesticos(equipos) {
  const cuerpoTabla = document.getElementById('tabla-electrodomesticos');
  cuerpoTabla.innerHTML = '';

  if (equipos.length === 0) {
    cuerpoTabla.innerHTML = `<tr><td colspan="7">No hay electrodomesticos registrados en este hogar.</td></tr>`;
    return;
  }

  equipos.forEach((equipo) => {
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td>${equipo.nombre}</td>
      <td>${equipo.categoria}</td>
      <td>${equipo.potencia_watts}</td>
      <td>${equipo.cantidad}</td>
      <td>${equipo.horas_uso_diario}</td>
      <td>${equipo.dias_uso_semana}</td>
      <td class="acciones-tabla">
        <button class="btn btn-pequeno" onclick='cargarParaEditar(${JSON.stringify(equipo)})'>Editar</button>
        <button class="btn btn-peligro btn-pequeno" onclick="eliminarElectrodomestico(${equipo.id_electrodomestico})">Eliminar</button>
      </td>
    `;
    cuerpoTabla.appendChild(fila);
  });
}

async function guardarElectrodomestico(evento) {
  evento.preventDefault();
  ocultarMensaje('mensaje-electro');
  ocultarMensaje('mensaje-exito-electro');

  const id_hogar = obtenerHogarSeleccionado();
  const id_electrodomestico = document.getElementById('id_electrodomestico').value;

  const datos = {
    nombre: document.getElementById('nombre').value.trim(),
    id_categoria: Number(document.getElementById('id_categoria').value),
    potencia_watts: Number(document.getElementById('potencia_watts').value),
    cantidad: Number(document.getElementById('cantidad').value),
    horas_uso_diario: Number(document.getElementById('horas_uso_diario').value),
    dias_uso_semana: Number(document.getElementById('dias_uso_semana').value)
  };

  if (
    !datos.nombre ||
    !datos.id_categoria ||
    datos.potencia_watts <= 0 ||
    datos.cantidad <= 0 ||
    datos.horas_uso_diario <= 0 ||
    datos.horas_uso_diario > 24 ||
    datos.dias_uso_semana < 1 ||
    datos.dias_uso_semana > 7
  ) {
    mostrarMensaje('mensaje-electro', 'Revisa los datos: todos los valores numericos deben ser positivos y estar en rangos validos.');
    return;
  }

  try {
    if (id_electrodomestico) {
      await apiFetch(`/electrodomesticos/${id_electrodomestico}`, {
        method: 'PUT',
        body: JSON.stringify(datos)
      });
      mostrarMensaje('mensaje-exito-electro', 'Electrodomestico actualizado correctamente.', 'exito');
    } else {
      await apiFetch(`/electrodomesticos/hogar/${id_hogar}`, {
        method: 'POST',
        body: JSON.stringify(datos)
      });
      mostrarMensaje('mensaje-exito-electro', 'Electrodomestico registrado correctamente.', 'exito');
    }

    cancelarEdicion();
    cargarElectrodomesticos();
  } catch (error) {
    mostrarMensaje('mensaje-electro', error.message);
  }
}

function cargarParaEditar(equipo) {
  document.getElementById('titulo-form').textContent = 'Editar electrodomestico';
  document.getElementById('id_electrodomestico').value = equipo.id_electrodomestico;
  document.getElementById('nombre').value = equipo.nombre;
  document.getElementById('id_categoria').value = equipo.id_categoria;
  document.getElementById('potencia_watts').value = equipo.potencia_watts;
  document.getElementById('cantidad').value = equipo.cantidad;
  document.getElementById('horas_uso_diario').value = equipo.horas_uso_diario;
  document.getElementById('dias_uso_semana').value = equipo.dias_uso_semana;
  document.getElementById('btn-guardar-electro').textContent = 'Actualizar electrodomestico';
  document.getElementById('btn-cancelar-edicion').style.display = 'inline-block';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function cancelarEdicion() {
  document.getElementById('form-electrodomestico').reset();
  document.getElementById('id_electrodomestico').value = '';
  document.getElementById('titulo-form').textContent = 'Agregar electrodomestico';
  document.getElementById('btn-guardar-electro').textContent = 'Guardar electrodomestico';
  document.getElementById('btn-cancelar-edicion').style.display = 'none';
  document.getElementById('cantidad').value = 1;
}

async function eliminarElectrodomestico(id_electrodomestico) {
  const confirmado = confirm('Seguro que deseas eliminar este electrodomestico?');
  if (!confirmado) return;

  try {
    await apiFetch(`/electrodomesticos/${id_electrodomestico}`, { method: 'DELETE' });
    cargarElectrodomesticos();
  } catch (error) {
    alert(error.message);
  }
}
