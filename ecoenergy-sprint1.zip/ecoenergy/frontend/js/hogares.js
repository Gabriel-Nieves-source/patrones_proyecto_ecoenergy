// Logica de gestion de hogares (CRUD).

document.addEventListener('DOMContentLoaded', () => {
  protegerPagina();
  renderizarBarraSuperior('hogares');
  cargarHogares();

  document.getElementById('form-nuevo-hogar').addEventListener('submit', crearHogar);
});

async function cargarHogares() {
  try {
    const hogares = await apiFetch('/hogares');
    pintarTablaHogares(hogares);
  } catch (error) {
    mostrarMensaje('mensaje-hogar', error.message);
  }
}

function pintarTablaHogares(hogares) {
  const cuerpoTabla = document.getElementById('tabla-hogares');
  cuerpoTabla.innerHTML = '';

  if (hogares.length === 0) {
    cuerpoTabla.innerHTML = `<tr><td colspan="3">Aun no tienes hogares registrados.</td></tr>`;
    return;
  }

  hogares.forEach((hogar) => {
    const fila = document.createElement('tr');
    const fecha = new Date(hogar.fecha_creacion).toLocaleDateString('es-CO');

    fila.innerHTML = `
      <td>${escaparHtml(hogar.nombre_hogar)}</td>
      <td>${fecha}</td>
      <td class="acciones-tabla">
        <button class="btn btn-secundario btn-pequeno" onclick="seleccionarHogar(${hogar.id_hogar}, '${escaparHtml(hogar.nombre_hogar)}')">
          Ver equipos
        </button>
        <button class="btn btn-pequeno" onclick="editarHogarPrompt(${hogar.id_hogar}, '${escaparHtml(hogar.nombre_hogar)}')">
          Editar
        </button>
        <button class="btn btn-peligro btn-pequeno" onclick="eliminarHogar(${hogar.id_hogar})">
          Eliminar
        </button>
      </td>
    `;
    cuerpoTabla.appendChild(fila);
  });
}

async function crearHogar(evento) {
  evento.preventDefault();
  ocultarMensaje('mensaje-hogar');
  ocultarMensaje('mensaje-exito-hogar');

  const nombre_hogar = document.getElementById('nombre_hogar').value.trim();

  if (!nombre_hogar) {
    mostrarMensaje('mensaje-hogar', 'El nombre del hogar es obligatorio.');
    return;
  }

  try {
    await apiFetch('/hogares', {
      method: 'POST',
      body: JSON.stringify({ nombre_hogar })
    });

    document.getElementById('nombre_hogar').value = '';
    mostrarMensaje('mensaje-exito-hogar', 'Hogar creado correctamente.', 'exito');
    cargarHogares();
  } catch (error) {
    mostrarMensaje('mensaje-hogar', error.message);
  }
}

async function editarHogarPrompt(id_hogar, nombreActual) {
  const nuevoNombre = prompt('Nuevo nombre del hogar:', nombreActual);
  if (nuevoNombre === null || nuevoNombre.trim() === '') return;

  try {
    await apiFetch(`/hogares/${id_hogar}`, {
      method: 'PUT',
      body: JSON.stringify({ nombre_hogar: nuevoNombre.trim() })
    });
    cargarHogares();
  } catch (error) {
    alert(error.message);
  }
}

async function eliminarHogar(id_hogar) {
  const confirmado = confirm('Seguro que deseas eliminar este hogar? Se eliminaran tambien sus electrodomesticos.');
  if (!confirmado) return;

  try {
    await apiFetch(`/hogares/${id_hogar}`, { method: 'DELETE' });

    if (obtenerHogarSeleccionado() == id_hogar) {
      localStorage.removeItem('eco_hogar_seleccionado');
    }

    cargarHogares();
  } catch (error) {
    alert(error.message);
  }
}

function seleccionarHogar(id_hogar, nombre_hogar) {
  guardarHogarSeleccionado(id_hogar);
  localStorage.setItem('eco_hogar_nombre', nombre_hogar);
  window.location.href = 'electrodomesticos.html';
}

function escaparHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto;
  return div.innerHTML;
}
