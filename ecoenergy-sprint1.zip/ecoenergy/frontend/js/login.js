// Logica de la pagina de inicio de sesion.

document.addEventListener('DOMContentLoaded', () => {
  // Si ya hay sesion activa, redirige directo al dashboard.
  if (obtenerToken()) {
    window.location.href = 'dashboard.html';
    return;
  }

  const formulario = document.getElementById('form-login');

  formulario.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    ocultarMensaje('mensaje-login');

    const correo = document.getElementById('correo').value.trim();
    const password = document.getElementById('password').value;

    if (!correo || !password) {
      mostrarMensaje('mensaje-login', 'Debes ingresar correo y contrasena.');
      return;
    }

    try {
      const respuesta = await apiFetch('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ correo, password })
      });

      guardarSesion(respuesta.token, respuesta.usuario);
      window.location.href = 'dashboard.html';
    } catch (error) {
      mostrarMensaje('mensaje-login', error.message);
    }
  });
});
