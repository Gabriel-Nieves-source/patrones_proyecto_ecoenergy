// Funciones compartidas por todas las paginas del frontend.

const API_BASE_URL = 'http://localhost:3000/api';

// ---------- Sesion ----------
function obtenerToken() {
  return localStorage.getItem('eco_token');
}

function obtenerUsuario() {
  const datos = localStorage.getItem('eco_usuario');
  return datos ? JSON.parse(datos) : null;
}

function guardarSesion(token, usuario) {
  localStorage.setItem('eco_token', token);
  localStorage.setItem('eco_usuario', JSON.stringify(usuario));
}

function cerrarSesion() {
  localStorage.removeItem('eco_token');
  localStorage.removeItem('eco_usuario');
  localStorage.removeItem('eco_hogar_seleccionado');
  window.location.href = 'index.html';
}

// Redirige al login si no hay sesion activa. Se llama en cada
// pagina protegida (dashboard, hogares, electrodomesticos, estadisticas).
function protegerPagina() {
  if (!obtenerToken()) {
    window.location.href = 'index.html';
  }
}

// ---------- Hogar seleccionado ----------
function obtenerHogarSeleccionado() {
  return localStorage.getItem('eco_hogar_seleccionado');
}

function guardarHogarSeleccionado(id_hogar) {
  localStorage.setItem('eco_hogar_seleccionado', id_hogar);
}

// ---------- Fetch con autenticacion ----------
async function apiFetch(ruta, opciones = {}) {
  const token = obtenerToken();

  const headers = {
    'Content-Type': 'application/json',
    ...(opciones.headers || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const respuesta = await fetch(`${API_BASE_URL}${ruta}`, {
    ...opciones,
    headers
  });

  const datos = await respuesta.json().catch(() => ({}));

  if (respuesta.status === 401) {
    // Token invalido o expirado: se cierra la sesion.
    cerrarSesion();
    throw new Error('Sesion expirada. Inicia sesion nuevamente.');
  }

  if (!respuesta.ok) {
    throw new Error(datos.error || 'Ocurrio un error inesperado.');
  }

  return datos;
}

// ---------- Formato ----------
function formatoCOP(valor) {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0
  }).format(valor || 0);
}

function formatoKwh(valor) {
  return `${Number(valor || 0).toFixed(2)} kWh`;
}

// ---------- Mensajes en pantalla ----------
function mostrarMensaje(idElemento, texto, tipo = 'error') {
  const elemento = document.getElementById(idElemento);
  if (!elemento) return;
  elemento.textContent = texto;
  elemento.className = tipo === 'error' ? 'mensaje-error' : 'mensaje-exito';
  elemento.style.display = 'block';
}

function ocultarMensaje(idElemento) {
  const elemento = document.getElementById(idElemento);
  if (elemento) elemento.style.display = 'none';
}

// ---------- Barra de navegacion dinamica ----------
function renderizarBarraSuperior(paginaActiva) {
  const contenedor = document.getElementById('barra-superior');
  if (!contenedor) return;

  const usuario = obtenerUsuario();
  const nombre = usuario ? usuario.nombre_completo.split(' ')[0] : '';

  const enlaces = [
    { href: 'dashboard.html', texto: 'Dashboard', id: 'dashboard' },
    { href: 'hogares.html', texto: 'Mis Hogares', id: 'hogares' },
    { href: 'electrodomesticos.html', texto: 'Electrodomesticos', id: 'electrodomesticos' },
    { href: 'estadisticas.html', texto: 'Estadisticas', id: 'estadisticas' }
  ];

  const navHtml = enlaces
    .map(
      (e) =>
        `<a href="${e.href}" class="${e.id === paginaActiva ? 'activo' : ''}">${e.texto}</a>`
    )
    .join('');

  contenedor.innerHTML = `
    <div class="logo">🌱 EcoEnergy</div>
    <nav>${navHtml}</nav>
    <div style="display:flex; align-items:center; gap:12px;">
      <span style="font-size:0.9rem;">Hola, ${nombre}</span>
      <button class="btn-salir" onclick="cerrarSesion()">Salir</button>
    </div>
  `;
}
