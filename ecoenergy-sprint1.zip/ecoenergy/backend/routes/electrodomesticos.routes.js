const express = require('express');
const router = express.Router();
const { verificarToken } = require('../middleware/auth.middleware');
const {
  listarPorHogar,
  crearElectrodomestico,
  editarElectrodomestico,
  eliminarElectrodomestico,
  listarCategorias
} = require('../controllers/electrodomesticos.controller');

router.use(verificarToken);

// Categorias (catalogo general, no depende de un hogar especifico)
router.get('/categorias', listarCategorias);

// CRUD anidado bajo un hogar
router.get('/hogar/:id_hogar', listarPorHogar);
router.post('/hogar/:id_hogar', crearElectrodomestico);
router.put('/:id_electrodomestico', editarElectrodomestico);
router.delete('/:id_electrodomestico', eliminarElectrodomestico);

module.exports = router;
