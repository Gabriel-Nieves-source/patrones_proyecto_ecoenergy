const express = require('express');
const router = express.Router();
const { verificarToken } = require('../middleware/auth.middleware');
const {
  listarHogares,
  crearHogar,
  editarHogar,
  eliminarHogar
} = require('../controllers/hogares.controller');

router.use(verificarToken); // todas las rutas de hogares requieren sesion

router.get('/', listarHogares);
router.post('/', crearHogar);
router.put('/:id_hogar', editarHogar);
router.delete('/:id_hogar', eliminarHogar);

module.exports = router;
