const express = require('express');
const router = express.Router();
const { verificarToken } = require('../middleware/auth.middleware');
const { obtenerConsumoHogar } = require('../controllers/consumo.controller');

router.use(verificarToken);

router.get('/hogar/:id_hogar', obtenerConsumoHogar);

module.exports = router;
