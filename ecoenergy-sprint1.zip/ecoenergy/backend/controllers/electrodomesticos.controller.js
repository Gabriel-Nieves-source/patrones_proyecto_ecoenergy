// CRUD de electrodomesticos. Antes de cualquier operacion se
// verifica que el hogar pertenezca al usuario autenticado,
// para que nadie modifique/elimine equipos de otro usuario.

const { pool } = require('../db');
const { verificarPropiedadHogar } = require('./hogares.controller');

function validarDatosElectrodomestico(datos) {
  const { nombre, id_categoria, potencia_watts, cantidad, horas_uso_diario, dias_uso_semana } = datos;

  if (!nombre || nombre.trim() === '') return 'El nombre es obligatorio.';
  if (!id_categoria) return 'La categoria es obligatoria.';
  if (potencia_watts === undefined || Number(potencia_watts) <= 0) return 'La potencia (W) debe ser mayor que 0.';
  if (cantidad === undefined || Number(cantidad) <= 0) return 'La cantidad debe ser mayor que 0.';
  if (horas_uso_diario === undefined || Number(horas_uso_diario) <= 0 || Number(horas_uso_diario) > 24) {
    return 'Las horas de uso diario deben estar entre 0 y 24.';
  }
  if (dias_uso_semana === undefined || Number(dias_uso_semana) < 1 || Number(dias_uso_semana) > 7) {
    return 'Los dias de uso por semana deben estar entre 1 y 7.';
  }
  return null;
}

async function listarPorHogar(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_hogar } = req.params;

    const esPropio = await verificarPropiedadHogar(id_hogar, id_usuario);
    if (!esPropio) {
      return res.status(403).json({ error: 'No tienes permiso sobre este hogar.' });
    }

    const [equipos] = await pool.query(
      `SELECT e.id_electrodomestico, e.nombre, e.potencia_watts, e.cantidad,
              e.horas_uso_diario, e.dias_uso_semana, e.id_categoria,
              c.nombre AS categoria
       FROM electrodomesticos e
       JOIN categorias c ON c.id_categoria = e.id_categoria
       WHERE e.id_hogar = ?
       ORDER BY e.fecha_creacion DESC`,
      [id_hogar]
    );

    return res.json(equipos);
  } catch (error) {
    console.error('Error en listarPorHogar:', error);
    return res.status(500).json({ error: 'Error del servidor al listar electrodomesticos.' });
  }
}

async function crearElectrodomestico(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_hogar } = req.params;
    const datos = req.body;

    const esPropio = await verificarPropiedadHogar(id_hogar, id_usuario);
    if (!esPropio) {
      return res.status(403).json({ error: 'No tienes permiso sobre este hogar.' });
    }

    const errorValidacion = validarDatosElectrodomestico(datos);
    if (errorValidacion) {
      return res.status(400).json({ error: errorValidacion });
    }

    const { nombre, id_categoria, potencia_watts, cantidad, horas_uso_diario, dias_uso_semana } = datos;

    const [resultado] = await pool.query(
      `INSERT INTO electrodomesticos
        (id_hogar, id_categoria, nombre, potencia_watts, cantidad, horas_uso_diario, dias_uso_semana)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id_hogar, id_categoria, nombre.trim(), potencia_watts, cantidad, horas_uso_diario, dias_uso_semana]
    );

    return res.status(201).json({
      mensaje: 'Electrodomestico registrado correctamente.',
      id_electrodomestico: resultado.insertId
    });
  } catch (error) {
    console.error('Error en crearElectrodomestico:', error);
    return res.status(500).json({ error: 'Error del servidor al registrar el electrodomestico.' });
  }
}

// Verifica que el electrodomestico pertenezca (via su hogar) al usuario.
async function verificarPropiedadElectrodomestico(id_electrodomestico, id_usuario) {
  const [filas] = await pool.query(
    `SELECT e.id_electrodomestico
     FROM electrodomesticos e
     JOIN hogares h ON h.id_hogar = e.id_hogar
     WHERE e.id_electrodomestico = ? AND h.id_usuario = ?`,
    [id_electrodomestico, id_usuario]
  );
  return filas.length > 0;
}

async function editarElectrodomestico(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_electrodomestico } = req.params;
    const datos = req.body;

    const esPropio = await verificarPropiedadElectrodomestico(id_electrodomestico, id_usuario);
    if (!esPropio) {
      return res.status(403).json({ error: 'No tienes permiso sobre este electrodomestico.' });
    }

    const errorValidacion = validarDatosElectrodomestico(datos);
    if (errorValidacion) {
      return res.status(400).json({ error: errorValidacion });
    }

    const { nombre, id_categoria, potencia_watts, cantidad, horas_uso_diario, dias_uso_semana } = datos;

    await pool.query(
      `UPDATE electrodomesticos
       SET nombre = ?, id_categoria = ?, potencia_watts = ?, cantidad = ?,
           horas_uso_diario = ?, dias_uso_semana = ?
       WHERE id_electrodomestico = ?`,
      [nombre.trim(), id_categoria, potencia_watts, cantidad, horas_uso_diario, dias_uso_semana, id_electrodomestico]
    );

    return res.json({ mensaje: 'Electrodomestico actualizado correctamente.' });
  } catch (error) {
    console.error('Error en editarElectrodomestico:', error);
    return res.status(500).json({ error: 'Error del servidor al editar el electrodomestico.' });
  }
}

async function eliminarElectrodomestico(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_electrodomestico } = req.params;

    const esPropio = await verificarPropiedadElectrodomestico(id_electrodomestico, id_usuario);
    if (!esPropio) {
      return res.status(403).json({ error: 'No tienes permiso sobre este electrodomestico.' });
    }

    await pool.query('DELETE FROM electrodomesticos WHERE id_electrodomestico = ?', [id_electrodomestico]);

    return res.json({ mensaje: 'Electrodomestico eliminado correctamente.' });
  } catch (error) {
    console.error('Error en eliminarElectrodomestico:', error);
    return res.status(500).json({ error: 'Error del servidor al eliminar el electrodomestico.' });
  }
}

async function listarCategorias(req, res) {
  try {
    const [categorias] = await pool.query('SELECT id_categoria, nombre FROM categorias ORDER BY nombre');
    return res.json(categorias);
  } catch (error) {
    console.error('Error en listarCategorias:', error);
    return res.status(500).json({ error: 'Error del servidor al listar categorias.' });
  }
}

module.exports = {
  listarPorHogar,
  crearElectrodomestico,
  editarElectrodomestico,
  eliminarElectrodomestico,
  listarCategorias,
  verificarPropiedadElectrodomestico
};
