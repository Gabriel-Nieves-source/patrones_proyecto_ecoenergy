// Calculo de consumo energetico y costo estimado.
// Formula base (decision documentada para resolver la
// inconsistencia entre documentos fuente):
//
//   consumo_diario_kWh  = (Watts * Cantidad * HorasUsoDiario) / 1000
//   consumo_semanal_kWh = consumo_diario_kWh * DiasUsoSemana
//   consumo_mensual_kWh = consumo_semanal_kWh * 4.345   (semanas/mes promedio)
//   consumo_anual_kWh   = consumo_mensual_kWh * 12
//
// Este calculo lo hace EcoEnergy, nunca una IA.

const { pool } = require('../db');
const { verificarPropiedadHogar } = require('./hogares.controller');

const SEMANAS_POR_MES = 4.345;

function calcularConsumo(electrodomestico) {
  const { potencia_watts, cantidad, horas_uso_diario, dias_uso_semana } = electrodomestico;

  const consumo_diario_kwh = (potencia_watts * cantidad * horas_uso_diario) / 1000;
  const consumo_semanal_kwh = consumo_diario_kwh * dias_uso_semana;
  const consumo_mensual_kwh = consumo_semanal_kwh * SEMANAS_POR_MES;
  const consumo_anual_kwh = consumo_mensual_kwh * 12;

  return {
    consumo_diario_kwh: Number(consumo_diario_kwh.toFixed(3)),
    consumo_mensual_kwh: Number(consumo_mensual_kwh.toFixed(3)),
    consumo_anual_kwh: Number(consumo_anual_kwh.toFixed(3))
  };
}

async function obtenerTarifaActiva() {
  const [filas] = await pool.query(
    'SELECT valor_kwh_cop FROM tarifas WHERE activa = 1 ORDER BY fecha_actualizacion DESC LIMIT 1'
  );
  if (filas.length === 0) return 0;
  return Number(filas[0].valor_kwh_cop);
}

// Devuelve el consumo y costo detallado de un hogar completo,
// por electrodomestico y el total del hogar.
async function obtenerConsumoHogar(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_hogar } = req.params;

    const esPropio = await verificarPropiedadHogar(id_hogar, id_usuario);
    if (!esPropio) {
      return res.status(403).json({ error: 'No tienes permiso sobre este hogar.' });
    }

    const [equipos] = await pool.query(
      `SELECT e.id_electrodomestico, e.nombre, e.potencia_watts, e.cantidad,
              e.horas_uso_diario, e.dias_uso_semana, c.nombre AS categoria
       FROM electrodomesticos e
       JOIN categorias c ON c.id_categoria = e.id_categoria
       WHERE e.id_hogar = ?`,
      [id_hogar]
    );

    const tarifa_kwh_cop = await obtenerTarifaActiva();

    let totalDiarioKwh = 0;
    let totalMensualKwh = 0;
    let totalAnualKwh = 0;

    const detalle = equipos.map((equipo) => {
      const consumo = calcularConsumo(equipo);

      totalDiarioKwh += consumo.consumo_diario_kwh;
      totalMensualKwh += consumo.consumo_mensual_kwh;
      totalAnualKwh += consumo.consumo_anual_kwh;

      return {
        id_electrodomestico: equipo.id_electrodomestico,
        nombre: equipo.nombre,
        categoria: equipo.categoria,
        ...consumo,
        costo_diario_cop: Number((consumo.consumo_diario_kwh * tarifa_kwh_cop).toFixed(2)),
        costo_mensual_cop: Number((consumo.consumo_mensual_kwh * tarifa_kwh_cop).toFixed(2)),
        costo_anual_cop: Number((consumo.consumo_anual_kwh * tarifa_kwh_cop).toFixed(2))
      };
    });

    // Electrodomestico de mayor consumo (para el dashboard)
    let mayorConsumidor = null;
    if (detalle.length > 0) {
      mayorConsumidor = detalle.reduce((max, actual) =>
        actual.consumo_mensual_kwh > max.consumo_mensual_kwh ? actual : max
      );
    }

    return res.json({
      id_hogar: Number(id_hogar),
      tarifa_kwh_cop,
      resumen_hogar: {
        consumo_diario_kwh: Number(totalDiarioKwh.toFixed(3)),
        consumo_mensual_kwh: Number(totalMensualKwh.toFixed(3)),
        consumo_anual_kwh: Number(totalAnualKwh.toFixed(3)),
        costo_diario_cop: Number((totalDiarioKwh * tarifa_kwh_cop).toFixed(2)),
        costo_mensual_cop: Number((totalMensualKwh * tarifa_kwh_cop).toFixed(2)),
        costo_anual_cop: Number((totalAnualKwh * tarifa_kwh_cop).toFixed(2))
      },
      mayor_consumidor: mayorConsumidor,
      detalle_por_electrodomestico: detalle

      // TODO: INTEGRACION IA - este endpoint ya entrega el consumo y costo
      // calculados por EcoEnergy (nunca por la IA). En una futura iteracion,
      // este mismo JSON podria enviarse a un servicio de IA externo para
      // generar recomendaciones personalizadas o interpretar los habitos
      // de consumo, sin que la IA participe en el calculo matematico.
    });
  } catch (error) {
    console.error('Error en obtenerConsumoHogar:', error);
    return res.status(500).json({ error: 'Error del servidor al calcular el consumo.' });
  }
}

module.exports = { obtenerConsumoHogar };
