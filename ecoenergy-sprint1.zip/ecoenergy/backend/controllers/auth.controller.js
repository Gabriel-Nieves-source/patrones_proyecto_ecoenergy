// Controlador de autenticacion: registro, login.
// Contrasenas nunca se guardan en texto plano (bcrypt).

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();
const { pool } = require('../db');

const SALT_ROUNDS = 10;

// Validacion simple de correo
function esCorreoValido(correo) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo);
}

async function registrar(req, res) {
  try {
    const { nombre_completo, correo, password, confirmar_password } = req.body;

    if (!nombre_completo || !correo || !password || !confirmar_password) {
      return res.status(400).json({ error: 'Todos los campos son obligatorios.' });
    }
    if (!esCorreoValido(correo)) {
      return res.status(400).json({ error: 'El correo no tiene un formato valido.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'La contrasena debe tener minimo 6 caracteres.' });
    }
    if (password !== confirmar_password) {
      return res.status(400).json({ error: 'Las contrasenas no coinciden.' });
    }

    const [existentes] = await pool.query(
      'SELECT id_usuario FROM usuarios WHERE correo = ?',
      [correo]
    );
    if (existentes.length > 0) {
      return res.status(409).json({ error: 'Ya existe una cuenta con ese correo.' });
    }

    const password_hash = await bcrypt.hash(password, SALT_ROUNDS);

    const [resultado] = await pool.query(
      'INSERT INTO usuarios (nombre_completo, correo, password_hash) VALUES (?, ?, ?)',
      [nombre_completo, correo, password_hash]
    );

    return res.status(201).json({
      mensaje: 'Usuario registrado correctamente.',
      id_usuario: resultado.insertId
    });
  } catch (error) {
    console.error('Error en registrar:', error);
    return res.status(500).json({ error: 'Error del servidor al registrar el usuario.' });
  }
}

async function login(req, res) {
  try {
    const { correo, password } = req.body;

    if (!correo || !password) {
      return res.status(400).json({ error: 'Correo y contrasena son obligatorios.' });
    }

    const [filas] = await pool.query(
      'SELECT id_usuario, nombre_completo, correo, password_hash, activo FROM usuarios WHERE correo = ?',
      [correo]
    );

    if (filas.length === 0) {
      return res.status(401).json({ error: 'Credenciales incorrectas.' });
    }

    const usuario = filas[0];

    if (!usuario.activo) {
      return res.status(403).json({ error: 'Cuenta desactivada. Contacta al administrador.' });
    }

    const coincide = await bcrypt.compare(password, usuario.password_hash);
    if (!coincide) {
      return res.status(401).json({ error: 'Credenciales incorrectas.' });
    }

    const token = jwt.sign(
      { id_usuario: usuario.id_usuario, correo: usuario.correo },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
    );

    return res.json({
      mensaje: 'Inicio de sesion exitoso.',
      token,
      usuario: {
        id_usuario: usuario.id_usuario,
        nombre_completo: usuario.nombre_completo,
        correo: usuario.correo
      }
    });
  } catch (error) {
    console.error('Error en login:', error);
    return res.status(500).json({ error: 'Error del servidor al iniciar sesion.' });
  }
}

module.exports = { registrar, login };
