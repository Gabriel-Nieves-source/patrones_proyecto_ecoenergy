// CRUD de hogares. Todas las consultas estan filtradas por
// id_usuario para que un usuario nunca vea hogares ajenos.

const { pool } = require('../db');

async function listarHogares(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const [hogares] = await pool.query(
      'SELECT id_hogar, nombre_hogar, fecha_creacion FROM hogares WHERE id_usuario = ? ORDER BY fecha_creacion DESC',
      [id_usuario]
    );
    return res.json(hogares);
  } catch (error) {
    console.error('Error en listarHogares:', error);
    return res.status(500).json({ error: 'Error del servidor al listar hogares.' });
  }
}

async function crearHogar(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { nombre_hogar } = req.body;

    if (!nombre_hogar || nombre_hogar.trim() === '') {
      return res.status(400).json({ error: 'El nombre del hogar es obligatorio.' });
    }

    const [resultado] = await pool.query(
      'INSERT INTO hogares (id_usuario, nombre_hogar) VALUES (?, ?)',
      [id_usuario, nombre_hogar.trim()]
    );

    return res.status(201).json({
      mensaje: 'Hogar creado correctamente.',
      id_hogar: resultado.insertId
    });
  } catch (error) {
    console.error('Error en crearHogar:', error);
    return res.status(500).json({ error: 'Error del servidor al crear el hogar.' });
  }
}

// Verifica que el hogar pertenezca al usuario autenticado.
async function verificarPropiedadHogar(id_hogar, id_usuario) {
  const [filas] = await pool.query(
    'SELECT id_hogar FROM hogares WHERE id_hogar = ? AND id_usuario = ?',
    [id_hogar, id_usuario]
  );
  return filas.length > 0;
}

async function editarHogar(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_hogar } = req.params;
    const { nombre_hogar } = req.body;

    if (!nombre_hogar || nombre_hogar.trim() === '') {
      return res.status(400).json({ error: 'El nombre del hogar es obligatorio.' });
    }

    const esPropio = await verificarPropiedadHogar(id_hogar, id_usuario);
    if (!esPropio) {
      return res.status(403).json({ error: 'No tienes permiso sobre este hogar.' });
    }

    await pool.query(
      'UPDATE hogares SET nombre_hogar = ? WHERE id_hogar = ?',
      [nombre_hogar.trim(), id_hogar]
    );

    return res.json({ mensaje: 'Hogar actualizado correctamente.' });
  } catch (error) {
    console.error('Error en editarHogar:', error);
    return res.status(500).json({ error: 'Error del servidor al editar el hogar.' });
  }
}

async function eliminarHogar(req, res) {
  try {
    const { id_usuario } = req.usuario;
    const { id_hogar } = req.params;

    const esPropio = await verificarPropiedadHogar(id_hogar, id_usuario);
    if (!esPropio) {
      return res.status(403).json({ error: 'No tienes permiso sobre este hogar.' });
    }

    // ON DELETE CASCADE en la BD elimina tambien sus electrodomesticos.
    await pool.query('DELETE FROM hogares WHERE id_hogar = ?', [id_hogar]);

    return res.json({ mensaje: 'Hogar eliminado correctamente.' });
  } catch (error) {
    console.error('Error en eliminarHogar:', error);
    return res.status(500).json({ error: 'Error del servidor al eliminar el hogar.' });
  }
}

module.exports = {
  listarHogares,
  crearHogar,
  editarHogar,
  eliminarHogar,
  verificarPropiedadHogar
};
