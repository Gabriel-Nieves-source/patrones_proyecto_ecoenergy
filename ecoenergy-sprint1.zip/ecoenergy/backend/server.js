// Punto de entrada del backend EcoEnergy.

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { verificarConexion } = require('./db');

const authRoutes = require('./routes/auth.routes');
const hogaresRoutes = require('./routes/hogares.routes');
const electrodomesticosRoutes = require('./routes/electrodomesticos.routes');
const consumoRoutes = require('./routes/consumo.routes');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Rutas de la API
app.use('/api/auth', authRoutes);
app.use('/api/hogares', hogaresRoutes);
app.use('/api/electrodomesticos', electrodomesticosRoutes);
app.use('/api/consumo', consumoRoutes);

// Ruta de salud, util para verificar que el backend esta activo
app.get('/api/health', (req, res) => {
  res.json({ estado: 'EcoEnergy backend activo' });
});

// Manejo de rutas no encontradas
app.use((req, res) => {
  res.status(404).json({ error: 'Ruta no encontrada.' });
});

// Manejo centralizado de errores no capturados
app.use((err, req, res, next) => {
  console.error('Error no controlado:', err);
  res.status(500).json({ error: 'Error interno del servidor.' });
});

async function iniciar() {
  await verificarConexion();
  app.listen(PORT, () => {
    console.log(`EcoEnergy backend corriendo en http://localhost:${PORT}`);
  });
}

iniciar();
