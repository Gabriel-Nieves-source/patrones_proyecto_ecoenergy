// Conexion a MySQL mediante pool de conexiones (mysql2/promise).
// Usa variables de entorno; nunca contrasenas escritas en el codigo.

require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Verificacion de conexion al iniciar el backend.
async function verificarConexion() {
  try {
    const conn = await pool.getConnection();
    console.log('Conexion a MySQL establecida correctamente.');
    conn.release();
  } catch (error) {
    console.error('Error al conectar con MySQL:', error.message);
    process.exit(1);
  }
}

module.exports = { pool, verificarConexion };
