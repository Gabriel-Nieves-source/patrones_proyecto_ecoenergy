// Middleware de autenticacion: verifica el token JWT enviado
// en el header Authorization: Bearer <token>.
// Protege rutas y asegura que cada usuario solo acceda a sus datos.

const jwt = require('jsonwebtoken');
require('dotenv').config();

function verificarToken(req, res, next) {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token no proporcionado.' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.usuario = { id_usuario: payload.id_usuario, correo: payload.correo };
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Token invalido o expirado.' });
  }
}

module.exports = { verificarToken };
