# EcoEnergy — Sprint 1

Aplicación web funcional para el control y optimización del consumo energético
residencial. Este Sprint 1 incluye: autenticación, gestión de hogares,
gestión de electrodomésticos, cálculo automático de consumo y costo, y un
dashboard básico con estadísticas — todo persistido en MySQL.

## Requisitos previos
- Node.js 18 o superior
- MySQL 8.0 o superior (recomendado, por uso de `CHECK` constraints)
- Un editor de código (VS Code recomendado)
- Un navegador moderno (Chrome, Firefox, Edge)

---

## 1. Instalar Node.js

1. Ir a https://nodejs.org y descargar la versión **LTS**.
2. Ejecutar el instalador y seguir los pasos por defecto.
3. Verificar la instalación abriendo una terminal y ejecutando:
   ```
   node -v
   npm -v
   ```
   Ambos comandos deben mostrar un número de versión (ej. `v20.11.0`).

---

## 2. Crear la base de datos MySQL

1. Abrir MySQL Workbench, phpMyAdmin, o la terminal de MySQL.
2. Si usas la terminal, conéctate con:
   ```
   mysql -u root -p
   ```
   e ingresa tu contraseña de MySQL cuando se solicite.
3. No es necesario crear la base de datos manualmente: el script
   `database/ecoenergy.sql` la crea automáticamente (`CREATE DATABASE ecoenergy`).

---

## 3. Ejecutar el archivo ecoenergy.sql

**Opción A — Desde la terminal:**
```
mysql -u root -p < database/ecoenergy.sql
```

**Opción B — Desde MySQL Workbench:**
1. Abrir el archivo `database/ecoenergy.sql` (File → Open SQL Script).
2. Ejecutar todo el script con el ícono de rayo ⚡ (Execute).

**Verificación:**
```sql
USE ecoenergy;
SHOW TABLES;
SELECT * FROM categorias;
SELECT * FROM tarifas;
```
Debes ver 5 tablas (`usuarios`, `hogares`, `categorias`, `electrodomesticos`,
`tarifas`), 7 categorías precargadas y 1 tarifa activa de 850.00 COP/kWh.

---

## 4. Configurar el archivo .env

1. Entrar a la carpeta `backend/`.
2. Copiar el archivo de ejemplo:
   ```
   cp .env.example .env
   ```
   (En Windows: copiar y pegar manualmente el archivo, o usar `copy .env.example .env`)
3. Abrir `.env` y completar con tus datos reales de MySQL:
   ```
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=tu_password_real_de_mysql
   DB_NAME=ecoenergy

   JWT_SECRET=una_clave_larga_y_dificil_de_adivinar_123456
   JWT_EXPIRES_IN=8h

   PORT=3000
   ```
4. Guardar el archivo. **Nunca subas este `.env` a un repositorio público.**

---

## 5. Instalar las dependencias

1. Desde la terminal, entra a la carpeta del backend:
   ```
   cd backend
   ```
2. Instala las dependencias:
   ```
   npm install
   ```
3. Espera a que termine (crea la carpeta `node_modules`).

---

## 6. Iniciar el backend

Dentro de `backend/`, ejecuta:
```
npm start
```

Deberías ver en la consola:
```
✅ Conexión a MySQL establecida correctamente.
🚀 EcoEnergy backend corriendo en http://localhost:3000
```

Si ves un error de conexión, revisa que:
- MySQL esté corriendo (servicio activo).
- Los datos en `.env` sean correctos (usuario, contraseña, puerto).

*(Opcional para desarrollo: `npm run dev` usa `nodemon` y reinicia el servidor automáticamente al guardar cambios.)*

---

## 7. Abrir la aplicación (frontend)

El frontend es HTML/CSS/JS puro, sin build. Dos formas de abrirlo:

**Opción A — Extensión Live Server (recomendada, VS Code):**
1. Instalar la extensión "Live Server" en VS Code.
2. Clic derecho sobre `frontend/index.html` → "Open with Live Server".
3. Se abrirá en algo como `http://127.0.0.1:5500/frontend/index.html`.

**Opción B — Abrir el archivo directamente:**
1. Doble clic en `frontend/index.html`.
2. Se abrirá en el navegador como `file:///.../index.html`.

> Nota: con la Opción B, algunos navegadores son más estrictos con CORS.
> Si tienes problemas de conexión con la API, usa la Opción A.

---

## 8. Probar el registro

1. En `index.html`, clic en "Regístrate aquí".
2. Llenar el formulario:
   - Nombre completo: `María Gómez`
   - Correo: `maria@ejemplo.com`
   - Contraseña: `eco2026!`
   - Confirmar contraseña: `eco2026!`
3. Clic en "Crear cuenta".
4. Resultado esperado: mensaje de éxito y redirección al login.

---

## 9. Probar el login

1. En `index.html`, ingresar:
   - Correo: `maria@ejemplo.com`
   - Contraseña: `eco2026!`
2. Clic en "Iniciar sesión".
3. Resultado esperado: redirección a `dashboard.html`.

---

## 10. Crear un hogar

1. En el menú superior, clic en "Mis Hogares".
2. Escribir un nombre, ej. `Casa Principal`.
3. Clic en "Crear hogar".
4. Resultado esperado: el hogar aparece en la tabla inferior.

---

## 11. Registrar un electrodoméstico

1. Desde "Mis Hogares", clic en "Ver equipos" sobre "Casa Principal"
   (o ir directo a "Electrodomésticos" en el menú).
2. Llenar el formulario:
   - Nombre: `Nevera`
   - Categoría: `Refrigeración`
   - Potencia: `300`
   - Cantidad: `1`
   - Horas de uso diario: `24`
   - Días de uso por semana: `7`
3. Clic en "Guardar electrodoméstico".
4. Resultado esperado: el equipo aparece en la tabla de electrodomésticos.

---

## 12. Verificar que el consumo se calcula

1. Ir a "Dashboard" o "Estadísticas".
2. Verificar que las tarjetas muestran un consumo mensual aproximado de
   **219 kWh** y un costo estimado aproximado de **$186.142 COP**
   (con la tarifa por defecto de 850 COP/kWh).
3. Editar la Nevera y cambiar las horas de uso diario a `12`.
4. Volver al Dashboard: el consumo mensual debe reducirse a la mitad
   automáticamente.

---

## 13. Verificar que los datos realmente se almacenan en MySQL

Desde una terminal o MySQL Workbench:
```sql
USE ecoenergy;

SELECT * FROM usuarios;
SELECT * FROM hogares;
SELECT * FROM electrodomesticos;
```

Debes ver:
- Tu usuario registrado (con `password_hash` cifrado, nunca en texto plano).
- El hogar "Casa Principal" asociado a tu `id_usuario`.
- El electrodoméstico "Nevera" asociado al `id_hogar` correcto.

Si estos datos aparecen correctamente en MySQL después de haber usado
solo la interfaz web, se confirma que **EcoEnergy no es una maqueta**:
los datos ingresados desde el navegador se guardan, consultan, actualizan
y eliminan realmente en la base de datos.

---

## Estructura del proyecto

```
ecoenergy/
├── frontend/       → HTML, CSS y JS separados (sin frameworks)
├── backend/        → API REST en Node.js + Express
├── database/       → Script SQL completo (ecoenergy.sql)
└── README.md       → Este archivo
```

## Notas sobre el alcance del Sprint 1

- La **Inteligencia Artificial no está implementada** en esta entrega.
  El punto de integración futura está señalado con un comentario
  `// TODO: INTEGRACIÓN IA` en `backend/controllers/consumo.controller.js`.
- El **simulador de ahorro** y las **recomendaciones automáticas** quedan
  para una siguiente iteración, según lo priorizado para este Sprint 1.
- La fórmula de cálculo mensual usa un promedio de **4.345 semanas/mes**
  para convertir "días de uso por semana" en consumo mensual real. Esta
  decisión está documentada en el controlador `consumo.controller.js`.

## Pruebas manuales (evidencia de Sprint 1)

Ver el archivo `PRUEBAS.md` para los casos de prueba HU-01 a HU-06 con
entradas exactas y resultados esperados, listos para usar como evidencia
de entrega.
